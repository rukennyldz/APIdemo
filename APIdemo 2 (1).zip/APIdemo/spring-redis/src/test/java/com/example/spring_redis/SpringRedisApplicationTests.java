package com.example.spring_redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
