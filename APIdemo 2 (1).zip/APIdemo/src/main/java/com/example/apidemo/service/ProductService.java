package com.example.apidemo.service;

import org.springframework.stereotype.Service;

@Service
public class ProductService {

    public ProductService getProductById(Long productId) {

        return null;
    }

    public ProductService createProduct(ProductService product) {

        return null;
    }

    public ProductService updateProduct(Long productId, ProductService product) {

        return null;
    }

    public void deleteProduct(Long productId) {

    }



}
